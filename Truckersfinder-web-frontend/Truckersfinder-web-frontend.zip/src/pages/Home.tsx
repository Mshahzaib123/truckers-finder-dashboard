import React from 'react'


const Home = () => {
    return (
        <>
            <h1>Hello world</h1>
        </>
    )
}

export default Home
